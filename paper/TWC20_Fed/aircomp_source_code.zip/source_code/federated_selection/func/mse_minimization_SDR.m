function [m, min_mse,rank_is_one] = mse_minimization_SDR(H)
    [N,K] = size(H);
    cvx_begin quiet
%     cvx_solver sedumi
    variable M(N,N) hermitian semidefinite
    minimize(trace(M))
    subject to
        for k=1:K
            real(H(:,k)'*M*H(:,k))>=1;
        end
    cvx_end
    
    [u,s,v] = svd(M);
    rank_is_one =(rank(M,1e-6)<=1);
    m = u(:,1)*sqrt(s(1,1));

    min_mse = 0;
    for iter=1:K
        tmp = norm(m)^2/norm(m'*H(:,iter))^2;
        if tmp>min_mse
            min_mse = tmp;
        end
    end
end