function [active_user,  min_mse, num_of_users] = user_selection_DC(H,gamma,params)
maxiter = params.maxiter;
verb = params.verbosity;

    [N,K] = size(H);
    
    for c=0:K
        x = randn(K,1); M = randn(N,N)+1i*randn(N,N); M=M*M';
        x_abs = abs(x);
        x_partial = zeros(K,1);
        [~, ind] = sort(x_abs,'descend');
        x_partial(ind(c+1:end)) = 0;
        x_partial(ind(1:c))=sign(x(ind(1:c)));
        [u,~] = eigs(M,1);
        M_partial = u*u';
        obj0 = 0;

        for  iter = 1:maxiter
            cvx_begin quiet
            cvx_solver sdpt3
            variable M(N,N) hermitian semidefinite
            variable x(K,1)
            minimize(norm(x,1)-x_partial'*x+ real(trace((eye(N)-M_partial')* M)))
            subject to
                for k=1:K
                    trace(M)-gamma*real(H(:,k)'*M*H(:,k))<=x(k);
                end
                trace(M)>=1;
                x>=0;
            cvx_end
            err = abs(cvx_optval-obj0);

            x_abs = abs(x);
            x_partial = ones(K,1);
            [x_sorted, ind] = sort(x_abs,'descend');
            x_partial(ind(c+1:end)) = 0;
            x_partial(ind(1:c))=sign(x(ind(1:c)));

            [u,s] = eigs(M,1);
            M_partial = u*u';
            if verb>=2
                fprintf('c:%d, iter:%d/%d, err:%.3e, obj:%.3e\n', c, iter, maxiter, err,cvx_optval);
            end

            obj0 = cvx_optval;
            if err<1e-9 || cvx_optval<1e-7
                break;
            end
        end
        s = svd(M);
        feasibility = sum(vec(s(2:end,2:end)))<1e-6;
         if feasibility
             break;
         end
    end
    
    %% ordering
    [val,ind] = sort(x,'ascend');
    for active_user_num = K:-1:1
%         active_user_num = floor((user_lower+user_higher)/2);
        active_user = ind(1:active_user_num);
        [m, feasibility] = feasibility_DC(H(:,active_user),gamma,params);
        if verb>=2
            fprintf(' try user num: %d,  feasible:%d\n', active_user_num, feasibility);
        end
        if feasibility
            num_of_users = active_user_num;
            break;
        end
    end
    if ~feasibility
        num_of_users = 0;
        active_user = [];
        m=[];
        min_mse = nan;
    else
        min_mse = 0;
        for iter=1:num_of_users
            tmp = norm(m)^2/norm(m'*H(:,active_user(iter)))^2;
            if tmp>min_mse
                min_mse = tmp;
            end
        end
    end
end