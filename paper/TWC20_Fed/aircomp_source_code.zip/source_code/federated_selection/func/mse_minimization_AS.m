function [m, min_mse] = mse_minimization_AS(H)
    [N,K] = size(H);
    min_mse = inf;  best_antenna = 0;
    
    for n=1:N
        [val,ind]=min(abs((H(n,:)).^2));
        tmp_n=1/val;
        if tmp_n<min_mse
            min_mse = tmp_n;
            best_antenna = n;
            m = zeros(N,1);
            m(best_antenna)=H(n,ind);
        end
    end

end