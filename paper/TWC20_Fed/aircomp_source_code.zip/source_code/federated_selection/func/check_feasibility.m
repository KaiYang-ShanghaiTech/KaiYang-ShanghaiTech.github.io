function [feasible, requested] = check_feasibility(M,Tset,c, epsilon)
feasible = 1;
[K,T] = size(M);
requested = zeros(K,1);
for ii = 1:T
    x = M(~Tset(:,ii),ii);
    if sum(abs(x)>epsilon) > c
        feasible = 0;
        return;
    end
end


for ii = 1:K
    y = M(ii,:);
    tmp = find(abs(y)>epsilon);
    if length(tmp) > 1
        feasible = 0;
        return;
    elseif ~isempty(tmp)
        requested(ii)=tmp;
    end
end

end

