function [channel_use, required_message] = DC_main_effecient(CSI,rho,lambda,c)
max_iter = 1000;
[m,n] = size(CSI);
channel_use = m;
Requests = ~CSI;
CSI = ~Requests;

for r = 1:m   
    f = zeros(max_iter,1);
    obj_value = zeros(max_iter,1);
    
    W = randn(m,r) * randn(r,n);
    for ii = 1:max_iter
        
        Z = DC_subgradient_effecient(W,CSI,1,c,r,rho,lambda);
        
        for jj = 1:m
           W(jj,Requests(jj,:)) = Z(jj,Requests(jj,:))/(2*(1+lambda+rho));
           W(jj,CSI(jj,:)) = Z(jj,CSI(jj,:))/(2*(1+lambda));                     
        end
        
%         W = row_normalize(W);
        [f0,f1]= obj_DC_effecient(W,Z,CSI,rho,lambda,r,c);
        obj_value(ii) = abs(f0);
        f(ii) = f1;
        if (obj_value(ii)<1e-13) % || (ii>3 && abs((f(ii)-f(ii-1))/f(ii-1))<1e-3)
            break;
        end
    end

%    semilogy(obj_value);
    
    A = W;
    A(abs(A)<1e-3) = 0;
    [feasibility, requested] = check_feasibility(A,CSI,c,lambda > 0)
    if feasibility == 1
        channel_use = rank(A,1e-6);
        required_message = requested;
%             channel_use = r;
        break;
    end
end

end

