function [loss, dW]= compute_loss_grad(W,X,y,reg)
%% Compute the multiclass svm loss
delta = 1.0;
scores = X*W;
num_train = size(X,1);
ind = sub2ind(size(scores),1:num_train,y');

%compute the margins for all classes in one vector operation
margins = max(0,scores-repmat(scores(ind)',[1,size(scores,2)])+delta);

% on ind-th position scores[ind] - scores[ind] canceled and gave delta. We want
% to ignore the y-th position and only consider margin on max wrong class
margins(ind) = 0;
loss = sum(margins(:))/num_train;

loss = loss + reg*norm(W,'fro')^2;

%% Compute the multiclass svm gradients
binary = margins;
binary(margins>0) = 1;
row_sum = sum(binary,2);
binary(ind) = binary(ind) - row_sum';
dW = X'*binary/num_train;

dW = dW+2*reg*W;
end