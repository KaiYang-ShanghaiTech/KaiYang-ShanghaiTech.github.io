function [W, min_mse] = W_aggregation(W_worker,select_worker, H_channel_coeff, options)
    if ~isfield(options, 'over_the_air')
        over_the_air = [];
    else
        over_the_air = options.over_the_air;
    end
    if ~isfield(options, 'noise_vec')
        noise_vec = [];
    else
        noise_vec = options.noise_vec;
    end
    if ~isfield(options, 'H_amp')
        H_amp = [];
    else
        H_amp = options.H_amp;
    end
    if ~isfield(options, 'min_mse')
        min_mse = 0;
    else
        min_mse = options.min_mse;
    end
    noise_mat = options.noise_mat;
    weight = options.weight;

    if isempty(over_the_air)
        W = 0;%zeros(size(W_worker{select_worker(1)}));
        for k = 1:length(select_worker)
            worker_ind = select_worker(k);
            W = W+ weight(worker_ind)*W_worker{worker_ind};
        end
        W = W/sum(weight(select_worker));
        min_mse = 0;
    elseif strcmp(over_the_air,'select')
        W = zeros(size(W_worker{select_worker(1)}));
        for k = 1:length(select_worker)
            worker_ind = select_worker(k);
            W = W+ weight(worker_ind)*W_worker{worker_ind};
        end
        W  = W + H_amp*min_mse*abs(W).*randn(size(W));
        W = W/sum(weight(select_worker));
    end
end