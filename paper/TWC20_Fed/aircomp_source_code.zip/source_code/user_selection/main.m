clear all; clc;
rng('default');rng(1);
N = 6; K = 20;
gamma_set = [-10:5:30];%[-10:2:24];%4:2:30;%[10,1,1e-1, 1e-2,1e-3];%[12:-2:2, 1, 0.5];
testnum=500;
user_num_l1 = zeros(length(gamma_set),testnum);
user_num_reweighted = zeros(length(gamma_set),testnum);
user_num_DC = zeros(length(gamma_set),testnum);

params.maxiter = 100;
params.epsilon = 1e-5;
params.verbosity = 1;
p=0.5;

Max_Iter = 3000; % Maximum number of iterations
epsilon = 0.0001; % The relative error tolerance
parfor ti = 1:testnum
    H = randn(N,K);
    for k = 1:K
        H(:,k)=(randn(N,1)/sqrt(2)+1i*randn(N,1)/sqrt(2));%10^(-148.1/20)*
    end
    user_num_l1_tmp = zeros(length(gamma_set),1);
    user_num_reweighted_tmp = zeros(length(gamma_set),1);
    user_num_DC_tmp = zeros(length(gamma_set),1);
    for ri =1:length(gamma_set)
        gamma = 10^(gamma_set(ri)/10);
        fprintf('testnum: %d, r:%d,', ti, gamma_set(ri));
        [m, num_of_users, active_user] = user_selection_sdr_l1(H,gamma,params);
        user_num_l1_tmp(ri) = num_of_users;
        fprintf(' --SDR L1  num of users: %d',  num_of_users);

        [m, num_of_users, active_user] = user_selection_sdr_reweighted(H,gamma,p,params);
        user_num_reweighted_tmp(ri)=num_of_users;
        fprintf(' --SDR Reweighted # users: %d', num_of_users);
        
        [m, num_of_users,active_user] = user_selection_DC(H,gamma,params);
        user_num_DC_tmp(ri)=num_of_users;
        fprintf(' --DC num of users: %d ', num_of_users);
        
        fprintf('\n');
    end
    user_num_l1(:,ti) = user_num_l1_tmp;
    user_num_reweighted(:,ti) = user_num_reweighted_tmp;
    user_num_DC(:,ti) = user_num_DC_tmp;
end
save('selection.mat');
figure,plot(gamma_set, mean(user_num_l1, 2),'s-', 'LineWidth',1.5); hold on
plot(gamma_set, mean(user_num_reweighted,2),'d-', 'LineWidth',1.5);
plot(gamma_set, mean(user_num_DC,2),'p-', 'LineWidth',1.5);
lgnd = legend({'$\ell_1$+SDR','Reweighted $\ell_2$+SDR','Proposed DC'},'Interpreter','latex');
set(lgnd,'color','none');
xlabel('$\gamma$ [dB]','Interpreter','latex');
ylabel('# devices');
set(gca,'FontSize',14,'FontName','Times New Roman');
ylim([0,K]);
xlim([min(gamma_set), max(gamma_set)]);
set(gca,'FontSize',18,'FontName','Times New Roman');