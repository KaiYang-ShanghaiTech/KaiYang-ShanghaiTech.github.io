function [m, feasibility] = feasibility_branchbound(H,gamma,Max_Iter,epsilon)
    [N,K] = size(H);
    
   [m,final_lb,final_ub,lb_sequence,ub_sequence]=BranchBound_MultiCast(H,Max_Iter,epsilon);

    feasibility = 1;
    for iter=1:K
        flag = norm(m)^2/norm(m'*H(:,iter))^2<=gamma;
        if ~flag
            feasibility = 0;
        end
    end
end