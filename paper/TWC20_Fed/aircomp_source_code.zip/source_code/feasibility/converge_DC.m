function [m, feasibility,obj_set] = converge_DC(H,gamma,params,M0)
maxiter = params.maxiter;
verb = params.verb;

    [N,K] = size(H);

    
    [u,~,~] = svd(M0);
    M_partial = u(:,1)*u(:,1)';
    obj0 = 0;
    obj_set = zeros(maxiter+1,1);
    obj_set(1) = trace(M0)-norm(M0,2);

    for  iter = 1:maxiter
        cvx_begin quiet
        cvx_solver sdpt3
        variable M(N,N) hermitian semidefinite
        minimize(real(trace((eye(N)-M_partial')* M)))
        subject to
            for k=1:K
                trace(M)-gamma*real(H(:,k)'*M*H(:,k))<=0;
            end
            trace(M)>=1;
        cvx_end
        
        if strcmp(cvx_status,'Infeasible')
            feasibility = 0;
            m = nan;
            return;
        end
        err = abs(cvx_optval-obj0);

        [u,s] = eigs(M,1);
        M_partial = u(:,1)*u(:,1)';
        res = abs(norm(M,'fro')-s(1,1));
        obj_set(iter+1) = trace(M)-norm(M,2);
        if verb>=2
            fprintf('iter:%d/%d, obj:%.3e, err:%.3e, res:%.3e\n', iter, maxiter,obj_set(iter+1), err,  res);
        end
        

        obj0 = cvx_optval;
        if obj_set(iter+1)<1e-6 || err<1e-6
            break;
        end
    end
    [u,s,v] = svd(M);
    m = u(:,1);
    obj_set = obj_set(1:iter+1);

    feasibility = sum(vec(s(2:end,2:end)))<1e-6;
%     	feasibility = 1;
%     if feasibility
%         for iter=1:K
%             flag = norm(m)^2/norm(m'*H(:,iter))^2<=gamma;
%             if ~flag
%                 feasibility = 0;
%             end
%         end
%     end
        
    
%     for k=1:K
%         flag= (trace(M)-gamma*real(H(:,k)'*M*H(:,k))<=0);
%         if ~flag
%             feasibility = 0;
%         end
%     end
%     for iter=1:K
%         flag = norm(m)^2/norm(m'*H(:,iter))^2<=gamma;
%         if ~flag
%             feasibility = 0;
%         end
%     end
end