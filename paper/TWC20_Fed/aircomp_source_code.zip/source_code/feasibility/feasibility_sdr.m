function [m, feasibility] = feasibility_sdr(H,gamma)
    [N,K] = size(H);
    cvx_begin quiet
    cvx_solver sdpt3
    variable M(N,N) hermitian semidefinite
    minimize(0)
    subject to
        for k=1:K
            real(trace((eye(N)-gamma*H(:,k)*H(:,k)')*M))<=0;
%             trace(M)-gamma*real(H(:,k)'*M*H(:,k))<=0;
        end
        trace(M)>=1;
    cvx_end
    
    if strcmp(cvx_status,'Infeasible')
        feasibility = 0;
        m = nan;
        return;
    end
    [u,s] = eigs(M);
    m = u(:,1);
    if rank(M,1e-6)>1
%         expvar = zeros(N,N);
%         for iter = 1:100000
%             zi = chol(M,'lower');
%             xi = (randn(N,1)+1i*randn(N,1))/sqrt(2);
%             xi = zi*xi;
%             expvar = expvar+xi*xi';
%         end
%         norm(expvar/100000-M,'fro')
%         x = xi*zi;
        zi = chol(M,'lower');
        xi = (randn(N,1)+1i*randn(N,1))/sqrt(2);
        xi = zi*xi;
        min_eig = inf;
        for k=1:K
            tmp = abs(xi'*H(:,k));
            if tmp<min_eig
                min_eig = tmp;
            end
        end
        m = xi/min_eig;
    end
        
    feasibility = 1;
    for iter=1:K
        flag = norm(m)^2/norm(m'*H(:,iter))^2<=gamma;
        if ~flag
            feasibility = 0;
        end
    end
end