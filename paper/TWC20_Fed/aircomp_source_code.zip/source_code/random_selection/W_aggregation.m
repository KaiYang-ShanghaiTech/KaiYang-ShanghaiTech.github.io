function W = W_aggregation(W_worker,select_worker, H_channel_coeff, options)
    if ~isfield(options, 'H_amp')
        H_amp = 0;
    else
        H_amp = options.H_amp;
    end
    if ~isfield(options, 'min_mse')
        min_mse = [];
    else
        min_mse = options.min_mse;
    end
    weight = options.weight;
    noise_mat = options.noise_mat;
    mse_require = options.mse_require;
    W = 0;%zeros(size(W_worker{select_worker(1)}));
    for k = 1:length(select_worker)
        worker_ind = select_worker(k);
        W = W+ weight(worker_ind)*W_worker{worker_ind};
    end
    W  = W + mse_require*norm(W,'fro')*noise_mat;
    W = W/sum(weight(select_worker));
end