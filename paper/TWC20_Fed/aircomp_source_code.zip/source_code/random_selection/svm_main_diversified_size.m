clc;clear;%close all;
rng('default');
rng(2);
warning('off');
% cvx_solver sdpt3;
%% Data
addpath('E:\box_backup\dataset\cifar-10-batches-mat');
addpath('C:\Users\Line\Box\dataset\cifar-10-batches-mat');
addpath('D:\box_backup\dataset\cifar-10-batches-mat');
addpath('./func')
data1 = load('data_batch_1.mat');
data2 = load('data_batch_2.mat');
data3 = load('data_batch_3.mat');
data4 = load('data_batch_4.mat');
data5 = load('data_batch_5.mat');
data_test = load('test_batch.mat');

X = double([data1.data;data2.data;data3.data;data4.data;data5.data]);
y = double([data1.labels;data2.labels;data3.labels;data4.labels;data5.labels]);
num_train = 50000;
num_test = 10000;

train_perm = 1:num_train;
% train_perm = randperm(num_train);

X_train_tmp = [X(train_perm,:),ones(num_train,1)];
y_train_tmp = y(train_perm);
[val,ind] = sort(y_train_tmp,'descend');

y_train = y_train_tmp(ind);
X_train = X_train_tmp(ind,:);
clear y_train_tmp X_train_tmp X y;


X_test = [double(data_test.data),ones(num_test,1)];
y_test = double(data_test.labels);

mean_imag = mean(X_train,1);
X_train = X_train-repmat(mean_imag,num_train,1);
X_test = X_test-repmat(mean_imag,num_test,1);

data.X_train= X_train;
data.X_test= X_test;
data.y_train = y_train+1;
data.y_test = y_test+1;

cache_size = num_train/10;

%% Alogrithm parameter
lr = 1e-7;
reg = 1.5e4;
com_round = 25;
epoch = 2;
batch_size = 100;
num_worker = 10;
antenna_num = 4;
exp_num = 100;

PSNR_set = inf;
PSNR_set_len = length(PSNR_set);
loss1 = zeros(exp_num,PSNR_set_len,com_round+1);
acc_train1 = zeros(exp_num,PSNR_set_len,com_round+1);
acc_test1 = zeros(exp_num,PSNR_set_len,com_round+1);

loss2 = zeros(exp_num,PSNR_set_len,com_round+1);
acc_train2 = zeros(exp_num,PSNR_set_len,com_round+1);
acc_test2 = zeros(exp_num,PSNR_set_len,com_round+1);
channel_use2 =  zeros(exp_num,PSNR_set_len,com_round+1);

loss3 = zeros(exp_num,PSNR_set_len,com_round+1);
acc_train3 = zeros(exp_num,PSNR_set_len,com_round+1);
acc_test3 = zeros(exp_num,PSNR_set_len,com_round+1);
channel_use3 =  zeros(exp_num,PSNR_set_len,com_round+1);

loss4 = zeros(exp_num,PSNR_set_len,com_round+1);
acc_train4 = zeros(exp_num,PSNR_set_len,com_round+1);
acc_test4 = zeros(exp_num,PSNR_set_len,com_round+1);
channel_use4 =  zeros(exp_num,PSNR_set_len,com_round+1);

loss5 = zeros(exp_num,PSNR_set_len,com_round+1);
acc_train5 = zeros(exp_num,PSNR_set_len,com_round+1);
acc_test5 = zeros(exp_num,PSNR_set_len,com_round+1);
channel_use5 =  zeros(exp_num,PSNR_set_len,com_round+1);

area = 1;

params.num_worker = num_worker;

for SNR_it = 1: PSNR_set_len
%     P_over_sigma_square = 20;
    P_over_sigma_square = PSNR_set(SNR_it);
    mse_amp = 10^(-P_over_sigma_square/10);%*10^(148.1/20);%10^(-4.635);
    params.H_amp = mse_amp;
    
%     params.X_cord = area*randn(2,num_worker);
    user_loc = 2*(rand(2,num_worker)-0.5);
    %% allocate data for workers
    msg_size = 100; %%100 messages in total, one message for 100 items of data.
    msg_num = num_train/msg_size;
    tmp_size =rand(num_worker,1);
    tmp_size =cache_size/batch_size*num_worker*tmp_size/sum(tmp_size);
%     cache_size_set = cache_size*randi([1,5],[num_worker,1]);%[1.5*ones(num_worker/2,1); 0.5*ones(num_worker/2,1)];
    cache_size_set = round(tmp_size)*batch_size;% cache_size_set/sum(cache_size_set)*cache_size*num_worker;
    cache_size_set(end) = cache_size*num_worker-sum(cache_size_set(1:end-1));
%     params.cache_size_set = cache_size_set;
    cache_msg_num = cache_size_set/msg_size;            % each worker stores 10 messages.
    cum_cache_msg_num = cumsum([0;cache_msg_num(:)]);
    msg_indxs = 1:num_train/msg_size;%randperm(num_train/msg_size);
    worker = cell(num_worker,1);%cache_size);
    worker_msg = cell(num_worker,1);%cache_msg_num);
    for it = 1:num_worker
       ind = mod(cum_cache_msg_num(it):cum_cache_msg_num(it+1)-1,num_train/msg_size)+1;
       worker_msg{it} = msg_indxs(ind);%mod((it-1)*cache_msg_num:it*cache_msg_num-1, num_train/msg_size)+1;
       tmp = [];
       for t = 1:length(worker_msg{it})
           tmp = [tmp,(worker_msg{it}(t)-1)*msg_size+1:worker_msg{it}(t)*msg_size];
       end
       worker{it} = tmp;
    %    worker(it,:) = indxs(mod(vec((it-1)*cache_size:it*cache_size-1),num_train)+1); 
    end
    
    params.weight = cache_msg_num/max(cache_msg_num);
    params.cache_msg_num = cache_msg_num;
    params.msg_size = msg_size;
    params.worker = worker;
    params.worker_msg = worker_msg;
    params.verbosity = 1;
    params.rho = 1;
    params.lambda = 1;
    params.c = 2;
    params.epoch = epoch;
    
    loss1_tmp = cell(exp_num,1);
    loss2_tmp = cell(exp_num,1);
    loss3_tmp = cell(exp_num,1);
    loss4_tmp = cell(exp_num,1);
    loss5_tmp = cell(exp_num,1);
    acc_train1_tmp = cell(exp_num,1);
    acc_train2_tmp = cell(exp_num,1);
    acc_train3_tmp = cell(exp_num,1);
    acc_train4_tmp = cell(exp_num,1);
    acc_train5_tmp = cell(exp_num,1);
    acc_test1_tmp = cell(exp_num,1);
    acc_test2_tmp = cell(exp_num,1);
    acc_test3_tmp = cell(exp_num,1);
    acc_test4_tmp = cell(exp_num,1);
    acc_test5_tmp = cell(exp_num,1);
    for tt = 1:exp_num
        options = params;
        W0 = 1e-4*randn(size(X_train,2),max(data.y_train));
        H_channel_set = zeros(antenna_num,num_worker,com_round);
        for k = 1:num_worker
            d = norm(user_loc(:,k));
            H_channel_set(:,k,:)=d^(-1.88)*(randn(antenna_num,com_round)/sqrt(2)+1i*randn(antenna_num,com_round)/sqrt(2));%10^(-148.1/20)*d^(-1.88)*
        end
        
        noise_set = zeros(size(X_train,2),max(data.y_train),com_round);
        for n = 1:com_round
            noise_tmp = randn(size(X_train,2),max(data.y_train));
            noise_set(:,:,n) = noise_tmp/(prod(size(noise_tmp))*norm(noise_tmp(:)));%,'fro')*;
        end
        
        
        options.H_channel_set = H_channel_set;
        options.noise_set = noise_set;
        
        %% select 2
        options.over_the_air = 'select';
        options.select_num = 2;
        tmp = ones(num_worker,1);
        options.chance = tmp/sum(tmp);
        options.user_selection_algo = [];
        [loss, acc_train, acc_test]=train(data,lr,reg,com_round,...
            batch_size,W0,options);
        loss1_tmp{tt} = loss;
        acc_train1_tmp{tt} = acc_train;
        acc_test1_tmp{tt} = acc_test;

        %% select 4
        options.over_the_air = 'select';  %params.channel_use0 = 10;
        options.select_num = 4;
        tmp = ones(num_worker,1);
        options.chance = tmp/sum(tmp);
        options.user_selection_algo = [];
        [loss, acc_train, acc_test]=train(data,lr,reg,com_round,...
                            batch_size,W0,options);
        loss2_tmp{tt} = loss;
        acc_train2_tmp{tt} = acc_train;
        acc_test2_tmp{tt} = acc_test;

         %% select 6
        options.over_the_air = 'select';  %params.channel_use0 = 10;
        options.select_num = 6;
        tmp = ones(num_worker,1);
        options.chance = tmp/sum(tmp);
        options.user_selection_algo = [];
        [loss, acc_train, acc_test]=train(data,lr,reg,com_round,...
                            batch_size,W0,options);
        loss3_tmp{tt} = loss;
        acc_train3_tmp{tt} = acc_train;
        acc_test3_tmp{tt} = acc_test;
        
        %% select 8
        options.over_the_air = 'select';  %params.channel_use0 = 10;
        options.select_num = 8;
        tmp = ones(num_worker,1);
        options.chance = tmp/sum(tmp);
        options.user_selection_algo = [];
        [loss, acc_train, acc_test]=train(data,lr,reg,com_round,...
                            batch_size,W0,options);
        loss4_tmp{tt} = loss;
        acc_train4_tmp{tt} = acc_train;
        acc_test4_tmp{tt} = acc_test;
        
        %% select 10
        options.over_the_air = 'select';  %params.channel_use0 = 10;
        options.select_num = 10;
        tmp = ones(num_worker,1);
        options.chance = tmp/sum(tmp);
        options.user_selection_algo = [];
        [loss, acc_train, acc_test]=train(data,lr,reg,com_round,...
                            batch_size,W0,options);
        loss5_tmp{tt} = loss;
        acc_train5_tmp{tt} = acc_train;
        acc_test5_tmp{tt} = acc_test;
        
         
        fprintf('worker:%d, exp:%d, loss:%.2f,%.2f,%.2f,%.2f,%.2f\n',num_worker, tt, loss1_tmp{tt}(end),loss2_tmp{tt}(end),loss3_tmp{tt}(end),loss4_tmp{tt}(end),loss5_tmp{tt}(end));
    end
    loss1(:,SNR_it,:) = cell2mat(loss1_tmp);
    acc_train1(:,SNR_it,:) = cell2mat(acc_train1_tmp);
    acc_test1(:,SNR_it,:) = cell2mat(acc_test1_tmp);

    loss2(:,SNR_it,:) = cell2mat(loss2_tmp);
    acc_train2(:,SNR_it,:) = cell2mat(acc_train2_tmp);
    acc_test2(:,SNR_it,:) = cell2mat(acc_test2_tmp);

    loss3(:,SNR_it,:) = cell2mat(loss3_tmp);
    acc_train3(:,SNR_it,:) = cell2mat(acc_train3_tmp);
    acc_test3(:,SNR_it,:) = cell2mat(acc_test3_tmp);

    loss4(:,SNR_it,:) = cell2mat(loss4_tmp);
    acc_train4(:,SNR_it,:) = cell2mat(acc_train4_tmp);
    acc_test4(:,SNR_it,:) = cell2mat(acc_test4_tmp);
    
    loss5(:,SNR_it,:) = cell2mat(loss5_tmp);
    acc_train5(:,SNR_it,:) = cell2mat(acc_train5_tmp);
    acc_test5(:,SNR_it,:) = cell2mat(acc_test5_tmp);
end

clear  X_train y_train  X_test  y_test  data  data1  data2  data3  data4  data5  data_test;
save('user_selection_random_snr=inf.mat');
%% Plot
figure;
plot(0:com_round,mean(squeeze(loss1),1),'o-','Linewidth', 1.5);
hold on
plot(0:com_round,mean(squeeze(loss2),1),'s-','Linewidth', 1.5);
plot(0:com_round,mean(squeeze(loss3),1),'d-','Linewidth', 1.5);
plot(0:com_round,mean(squeeze(loss4),1),'p-','Linewidth', 1.5);
plot(0:com_round,mean(squeeze(loss5),1),'+-','Linewidth', 1.5);
xlabel('Round')
ylabel('Training loss')
legend({'# devices = 2','# devices = 4','# devices = 6', '# devices = 8', '# devices = 10'},'Interpreter','latex');%legend('No shuffling 1','No shuffling 2','No shuffling 3','Shuffling 1', 'Shuffling 2','Shuffling 3');
% ylim([1,3.8])
set(gca,'FontSize',18,'FontName','Times New Roman');


figure;
plot(0:com_round,mean(squeeze(acc_test1),1)/0.1,'o-','Linewidth', 1.5);
hold on
plot(0:com_round,mean(squeeze(acc_test2),1)/0.1,'s-','Linewidth', 1.5);
plot(0:com_round,mean(squeeze(acc_test3),1)/0.1,'d-','Linewidth', 1.5);
plot(0:com_round,mean(squeeze(acc_test4),1)/0.1,'p-','Linewidth', 1.5);
plot(0:com_round,mean(squeeze(acc_test5),1)/0.1,'+-','Linewidth', 1.5);
xlabel('Round')
ylabel('Prediction accuracy')
legend({'# devices = 2','# devices = 4','# devices = 6', '# devices = 8', '# devices = 10'},'Interpreter','latex');%legend('No shuffling 1','No shuffling 2','No shuffling 3','Shuffling 1', 'Shuffling 2','Shuffling 3');
% ylim([1,3.8])
set(gca,'FontSize',18,'FontName','Times New Roman');
